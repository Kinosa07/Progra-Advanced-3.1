﻿/*Espace pour les notes personneles lors de la création du projet. NE RIEN CODER DEDANS!!!
 * 
 * GameLoop: Facteur. Income: Point A > Point B.
 * 
 * Addition fight ennemis quand pas sur les senties battus (& Forcer le joueur a sortir des sentiers battus)
 * 
 * Component List[ Inventaire:OK, Movement:OK, Position:OK, Render:pas OK, Collision:pas OK, Map: OK ??]
 * 
 * Menu Component???
 * Shop Component???
 * Interact Component???
 * 
 * 
 * Ligne 47 Game Object
 * 
 * TODO: Ok-fy Movement et Render
 * 
 * Doing: RenderManager & RenderComponent (4 directions)
 * 
 * 
 * State Machine
 * 1 State par Type de Location (Shop/Inn, City, country, Planet, ...)
 * Qui gère la sortie du village/shop/inn etc...
 * 
 * Event Manager
 * 
 * RenderManager??? Et que fait RenderCompo si RenderManager existe
 * Fonctionnemtn Render: Parcourir un tableau de case. Ecrire " " si la case est vide et utiliser le render d'un objet a sa position
 * 
 * 
 * 
 * Event: Touches
 * 
 * Déplacement via touches
 * 
 * 
 * 
 * 
 * 
 * 
*/