﻿namespace Prog_3._1_RPG_game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameEngine engine = new GameEngine();

            engine.Run();
        }
    }
}
